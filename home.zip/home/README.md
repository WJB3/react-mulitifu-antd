npx babel --config-file ./babel.config.json --out-dir dist ./src

npm install @babel/preset-env @babel/preset-react @vue/babel-plugin-transform-vue-jsx @babel/plugin-proposal-decorators @babel/plugin-proposal-class-properties @babel/plugin-transform-runtime @babel/plugin-proposal-function-bind @babel/plugin-syntax-dynamic-import -D